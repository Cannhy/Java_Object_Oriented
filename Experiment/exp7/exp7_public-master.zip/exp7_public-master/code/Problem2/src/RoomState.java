public enum RoomState {
    SPARE,
    OCCUPIED,
    CLEANING
}
